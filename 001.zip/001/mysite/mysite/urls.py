
from django.contrib import admin
from django.urls import include, path
'''
urlpatterns = [
    path("polls/", include("polls.urls")),
    path("admin/", admin.site.urls),




]
'''

#from django.conf.urls import url, include
from django.conf.urls import include
from django.contrib import admin

urlpatterns = [
    path(r'pages/', include('django.contrib.flatpages.urls')),
    path(r'admin/', admin.site.urls),
    path("polls/", include("polls.urls")),
]



